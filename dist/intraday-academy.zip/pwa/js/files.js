/* Ordered script list — single source of truth for index.html, the service worker and the build. */
(function (root) {
  root.IA_FILES = [
    'js/engines/specs.js', 'js/engines/indicators.js', 'js/engines/risk.js', 'js/engines/options.js', 'js/engines/marketgen.js', 'js/engines/backtest.js', 'js/engines/clock.js', 'js/engines/execution.js',
    'js/content/curriculum.js', 'js/content/lessons-l1.js', 'js/content/lessons-l2a.js', 'js/content/lessons-l2b.js', 'js/content/lessons-l3a.js', 'js/content/lessons-l3b.js', 'js/content/lessons-l4.js',
    'js/content/indicators-lib.js', 'js/content/strategies.js', 'js/content/patterns.js', 'js/content/psychology.js', 'js/content/library.js',
    'js/core/db.js', 'js/core/ui.js', 'js/core/chart.js', 'js/core/progress.js', 'js/core/app.js',
    'js/modules/calculators.js', 'js/modules/academy.js', 'js/modules/technical.js', 'js/modules/chartlab.js', 'js/modules/markets.js', 'js/modules/simulator.js',
    'js/modules/strategies.js', 'js/modules/derivatives.js', 'js/modules/risk-journal.js', 'js/modules/quant.js', 'js/modules/misc.js',
  ];
})(typeof window !== 'undefined' ? window : globalThis);
